# 🧭 Yaw Fusion 센서 퓨전 튜닝 가이드

## 📋 개요

GPS COG(Course Over Ground)와 IMU yaw를 센서 퓨전하여 정확한 yaw를 얻는 시스템입니다.

### 🎯 목표
- **IMU yaw**: 정확하지만 장시간 사용 시 드리프트 발생
- **GPS COG**: 절대적이지만 노이즈가 많고 저속에서 부정확
- **퓨전 결과**: 두 센서의 장점을 결합한 정확하고 안정적인 yaw

## 🚀 실행 방법

### 1. 기본 실행
```bash
# 센서 퓨전 노드 실행
ros2 launch imu_pkg yaw_fusion.launch.py

# 튜닝 도구 실행 (별도 터미널)
ros2 run imu_pkg yaw_fusion_tuner
```

### 2. 파라미터 조정 실행
```bash
# Alpha 값 조정 (0.90~0.99)
ros2 launch imu_pkg yaw_fusion.launch.py alpha:=0.95

# 최소 GPS 속도 조정
ros2 launch imu_pkg yaw_fusion.launch.py min_gps_speed:=2.0

# 퓨전 방법 변경
ros2 launch imu_pkg yaw_fusion.launch.py fusion_method:=kalman
```

## 🎛️ 튜닝 파라미터

### 1. **Alpha (α) - 가장 중요한 파라미터**
- **범위**: 0.0 ~ 1.0
- **의미**: IMU 가중치 (1-α는 GPS 가중치)
- **공식**: `filtered_yaw = α × imu_yaw + (1-α) × gps_cog`

#### **시간에 따른 적응적 Alpha (NEW!)**
```python
# 자동 조정 (adaptive_alpha=True)
0~5분:    α = 0.98  # IMU 신뢰도 높음
5~30분:   α = 0.98 → 0.85  # 선형 감소
30분+:    α = 0.85 → 0.70  # 급격한 감소
드리프트 감지: α = α - 0.1  # 추가 감소
```

#### 수동 튜닝 가이드:
- **α = 0.98**: IMU 신뢰도 높음 (정적 환경, 짧은 시간)
- **α = 0.95**: 균형잡힌 설정 (일반적인 사용)
- **α = 0.90**: GPS 신뢰도 높음 (장시간 사용, 진동 환경)

### 2. **min_gps_speed**
- **범위**: 0.5 ~ 5.0 m/s
- **의미**: GPS COG 계산 최소 속도
- **권장값**: 1.0 m/s (도시 환경), 2.0 m/s (고속도로)

### 3. **gps_timeout**
- **범위**: 0.5 ~ 5.0 초
- **의미**: GPS 데이터 타임아웃
- **권장값**: 1.0 초

### 4. **adaptive_alpha (NEW!)**
- **범위**: true/false
- **의미**: 시간에 따른 적응적 Alpha 사용
- **권장값**: true (장시간 주행 시)

### 5. **drift_correction (NEW!)**
- **범위**: true/false
- **의미**: IMU 드리프트 감지 및 보정
- **권장값**: true (드리프트 문제 시)

### 6. **drift_based_alpha (NEW!)**
- **범위**: true/false
- **의미**: 드리프트 정도에 따른 Alpha 자동 조정
- **권장값**: true (드리프트 기반 조정 원할 시)

### 7. **drift_sensitivity (NEW!)**
- **범위**: 0.5 ~ 2.0
- **의미**: 드리프트 감도 (1.0 = 기본, >1.0 = 더 민감, <1.0 = 덜 민감)
- **권장값**: 1.0 (기본값)

## 🔧 튜닝 방법

### 1. **초기 설정**
```bash
# 기본 설정으로 시작
ros2 launch imu_pkg yaw_fusion.launch.py alpha:=0.95
```

### 2. **성능 모니터링**
```bash
# 필터링된 yaw 확인
rostopic echo /filtered_yaw

# 디버깅 정보 확인
rostopic echo /yaw_fusion_debug
```

### 3. **실시간 튜닝**
```bash
# Alpha 값 실시간 조정
ros2 param set /yaw_fusion_node alpha 0.92

# 최소 GPS 속도 조정
ros2 param set /yaw_fusion_node min_gps_speed 1.5
```

### 4. **성능 평가**
```bash
# 튜닝 도구로 성능 모니터링
ros2 run imu_pkg yaw_fusion_tuner
```

## 📊 성능 평가 기준

### 1. **각도 차이 (Angle Difference)**
- **목표**: 평균 3도 이하
- **측정**: GPS COG와 필터링된 yaw의 차이
- **모니터링**: `/yaw_fusion_debug` 토픽

### 2. **안정성 (Stability)**
- **목표**: 급격한 변화 없음
- **측정**: 연속된 yaw 값의 변화율
- **모니터링**: `/filtered_yaw` 토픽

### 3. **응답성 (Responsiveness)**
- **목표**: 방향 변화 시 빠른 추적
- **측정**: 실제 방향 변화와 필터링된 yaw의 지연
- **모니터링**: 실제 주행 테스트

## 🎯 시나리오별 튜닝

### 1. **도시 환경 (저속, 빈번한 방향 변화)**
```bash
ros2 launch imu_pkg yaw_fusion.launch.py \
    alpha:=0.92 \
    min_gps_speed:=1.0 \
    gps_timeout:=1.0 \
    adaptive_alpha:=true \
    drift_correction:=true
```

### 2. **고속도로 환경 (고속, 안정적 주행)**
```bash
ros2 launch imu_pkg yaw_fusion.launch.py \
    alpha:=0.98 \
    min_gps_speed:=2.0 \
    gps_timeout:=2.0 \
    adaptive_alpha:=true \
    drift_correction:=false
```

### 3. **장시간 주행 (드리프트 보정 중요) - RECOMMENDED!**
```bash
ros2 launch imu_pkg yaw_fusion.launch.py \
    alpha:=0.90 \
    min_gps_speed:=1.5 \
    gps_timeout:=1.5 \
    adaptive_alpha:=true \
    drift_correction:=true
```

### 4. **진동 환경 (IMU 노이즈 많음)**
```bash
ros2 launch imu_pkg yaw_fusion.launch.py \
    alpha:=0.85 \
    min_gps_speed:=1.0 \
    gps_timeout:=0.5 \
    adaptive_alpha:=true \
    drift_correction:=true
```

### 5. **IMU 드리프트 심한 환경 (NEW!)**
```bash
ros2 launch imu_pkg yaw_fusion.launch.py \
    alpha:=0.80 \
    min_gps_speed:=1.0 \
    gps_timeout:=1.0 \
    adaptive_alpha:=true \
    drift_correction:=true \
    drift_based_alpha:=true \
    drift_sensitivity:=1.5
```

### 6. **드리프트 기반 자동 조정 (RECOMMENDED!)**
```bash
ros2 launch imu_pkg yaw_fusion.launch.py \
    alpha:=0.95 \
    min_gps_speed:=1.0 \
    gps_timeout:=1.0 \
    adaptive_alpha:=true \
    drift_correction:=true \
    drift_based_alpha:=true \
    drift_sensitivity:=1.0
```

## 🔍 문제 해결

### 1. **GPS COG가 부정확한 경우**
- `min_gps_speed` 증가 (2.0 m/s 이상)
- `gps_timeout` 감소 (0.5초)
- `alpha` 증가 (0.95 이상)

### 2. **IMU 드리프트가 심한 경우 (NEW!)**
- `adaptive_alpha:=true` 활성화
- `drift_correction:=true` 활성화
- `alpha` 감소 (0.90 이하)
- `min_gps_speed` 감소 (1.0 m/s 이하)

### 3. **시간이 지날수록 정확도 저하**
- `adaptive_alpha:=true` 활성화 (자동 조정)
- `drift_correction:=true` 활성화
- 초기 `alpha` 값을 0.90 이하로 설정

### 4. **퓨전 결과가 불안정한 경우**
- `alpha` 조정 (0.92~0.96 범위)
- `adaptive_alpha:=true` 활성화
- GPS 신호 품질 확인
- IMU 보정 상태 확인

### 5. **드리프트 감지가 너무 민감한 경우**
- `drift_correction:=false` 비활성화
- 또는 드리프트 임계값 조정 (코드 수정 필요)

## 📈 모니터링 명령어

```bash
# 실시간 성능 모니터링
rostopic echo /yaw_fusion_debug

# 파라미터 확인
ros2 param list /yaw_fusion_node

# 파라미터 값 확인
ros2 param get /yaw_fusion_node alpha

# 파라미터 실시간 변경
ros2 param set /yaw_fusion_node alpha 0.93
```

## 🎯 최적화 팁

1. **단계적 튜닝**: Alpha를 0.95에서 시작하여 ±0.01씩 조정
2. **실제 주행 테스트**: 다양한 환경에서 테스트
3. **장시간 모니터링**: 30분 이상 주행하여 드리프트 확인
4. **GPS 품질 확인**: RTK GPS 사용 시 더 정확한 COG
5. **IMU 보정**: 정기적인 IMU 보정각도 업데이트

## 🚨 주의사항

- **GPS 신호 약한 지역**: Alpha 값을 높여 IMU 의존도 증가
- **터널/지하**: GPS 신호 없을 때 IMU만 사용
- **급격한 방향 변화**: GPS COG 지연으로 인한 오차 발생 가능
- **정지 상태**: GPS COG 계산 불가, IMU만 사용

이 가이드를 따라 단계적으로 튜닝하면 최적의 센서 퓨전 성능을 얻을 수 있습니다! 🚀
