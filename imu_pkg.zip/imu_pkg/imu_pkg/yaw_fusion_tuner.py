#!/usr/bin/env python3
"""
Yaw Fusion 센서 퓨전 튜닝 도구
- 실시간 파라미터 조정
- 센서 데이터 모니터링
- 퓨전 성능 평가
"""

import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64
from geometry_msgs.msg import Twist
import math
import time

class YawFusionTuner(Node):
    def __init__(self):
        super().__init__('yaw_fusion_tuner')
        
        # 구독자
        self.filtered_yaw_sub = self.create_subscription(
            Float64, '/filtered_yaw', self.filtered_yaw_callback, 10
        )
        self.debug_sub = self.create_subscription(
            Twist, '/yaw_fusion_debug', self.debug_callback, 10
        )
        
        # 퍼블리셔 (파라미터 조정용)
        self.alpha_pub = self.create_publisher(Float64, '/yaw_fusion/alpha', 10)
        
        # 상태 변수
        self.filtered_yaw = 0.0
        self.gps_cog = 0.0
        self.imu_yaw = 0.0
        self.gps_speed = 0.0
        self.gps_valid = False
        self.alpha = 0.98
        
        # 튜닝 파라미터
        self.alpha_min = 0.90
        self.alpha_max = 0.99
        self.alpha_step = 0.01
        
        # 성능 평가
        self.angle_diffs = []
        self.max_angle_diff = 0.0
        
        self.get_logger().info("🎛️ Yaw Fusion 튜너가 시작되었습니다!")
        self.get_logger().info("   실시간 파라미터 조정 및 성능 모니터링")
        self.get_logger().info("   Alpha 범위: {:.2f} ~ {:.2f}".format(self.alpha_min, self.alpha_max))
    
    def filtered_yaw_callback(self, msg):
        """필터링된 yaw 데이터 수신"""
        self.filtered_yaw = msg.data
    
    def debug_callback(self, msg):
        """디버깅 정보 수신"""
        self.gps_speed = msg.linear.x
        self.gps_valid = bool(msg.linear.y)
        self.gps_cog = math.radians(msg.linear.z)
        self.imu_yaw = math.radians(msg.angular.x)
        self.filtered_yaw = math.radians(msg.angular.y)
        self.alpha = msg.angular.z
        
        # 성능 평가
        if self.gps_valid:
            angle_diff = abs(self.gps_cog - self.filtered_yaw)
            if angle_diff > math.pi:
                angle_diff = 2 * math.pi - angle_diff
            
            self.angle_diffs.append(angle_diff)
            if len(self.angle_diffs) > 100:  # 최근 100개 샘플만 유지
                self.angle_diffs.pop(0)
            
            self.max_angle_diff = max(self.max_angle_diff, angle_diff)
    
    def adjust_alpha(self, direction):
        """Alpha 값 조정"""
        if direction == 'up':
            self.alpha = min(self.alpha + self.alpha_step, self.alpha_max)
        elif direction == 'down':
            self.alpha = max(self.alpha - self.alpha_step, self.alpha_min)
        
        # Alpha 값 발행
        msg = Float64()
        msg.data = self.alpha
        self.alpha_pub.publish(msg)
        
        self.get_logger().info(f"🎛️ Alpha 조정: {self.alpha:.3f}")
    
    def print_performance(self):
        """성능 평가 결과 출력"""
        if len(self.angle_diffs) > 10:
            avg_diff = sum(self.angle_diffs) / len(self.angle_diffs)
            max_diff = max(self.angle_diffs)
            
            self.get_logger().info(f"📊 성능 평가:")
            self.get_logger().info(f"   평균 각도 차이: {math.degrees(avg_diff):.1f}°")
            self.get_logger().info(f"   최대 각도 차이: {math.degrees(max_diff):.1f}°")
            self.get_logger().info(f"   현재 Alpha: {self.alpha:.3f}")
            self.get_logger().info(f"   GPS 유효성: {self.gps_valid}")
            self.get_logger().info(f"   GPS 속도: {self.gps_speed:.2f} m/s")
    
    def auto_tune(self):
        """자동 튜닝 (실험적)"""
        if len(self.angle_diffs) < 50:
            return
        
        avg_diff = sum(self.angle_diffs) / len(self.angle_diffs)
        
        # 성능이 좋지 않으면 Alpha 조정
        if avg_diff > math.radians(5.0):  # 5도 이상 차이
            if self.alpha > 0.95:
                self.adjust_alpha('down')
            else:
                self.adjust_alpha('up')
    
    def timer_callback(self):
        """주기적 성능 평가"""
        self.print_performance()
        # self.auto_tune()  # 자동 튜닝 (필요시 활성화)

def main(args=None):
    rclpy.init(args=args)
    node = YawFusionTuner()
    
    # 타이머 설정 (10초마다 성능 평가)
    timer = node.create_timer(10.0, node.timer_callback)
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
