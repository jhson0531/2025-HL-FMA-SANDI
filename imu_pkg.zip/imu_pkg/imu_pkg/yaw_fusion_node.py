#!/usr/bin/env python3
"""
GPS COG + IMU Yaw 센서 퓨전 노드
- GPS COG: Course Over Ground (진행 방향)
- IMU Yaw: 자이로스코프 기반 방향
- 센서 퓨전: Complementary Filter 또는 Kalman Filter
- 출력: /filtered_yaw 토픽으로 발행
"""

import rclpy
from rclpy.node import Node
import math
import numpy as np
from sensor_msgs.msg import Imu, NavSatFix
from std_msgs.msg import Float64
from geometry_msgs.msg import Twist
import utm
import time

class YawFusionNode(Node):
    def __init__(self):
        super().__init__('yaw_fusion_node')
        
        # 센서 퓨전 파라미터
        self.alpha = 0.98  # Complementary Filter 가중치 (0.0~1.0)
        self.gps_cog_weight = 0.02  # GPS COG 가중치
        self.imu_weight = 0.98  # IMU 가중치
        
        # 시간 기반 적응적 파라미터
        self.start_time = time.time()
        self.adaptive_alpha = True  # 적응적 Alpha 사용 여부
        
        # 드리프트 기반 적응적 파라미터
        self.drift_history = []  # 드리프트 히스토리
        self.max_drift_samples = 100  # 최대 샘플 수
        self.drift_threshold_light = math.radians(2.0)   # 경미한 드리프트 (5도)
        self.drift_threshold_medium = math.radians(4.0) # 중간 드리프트 (10도)
        self.drift_threshold_heavy = math.radians(6.0)  # 심한 드리프트 (20도)
        
        # 상태 변수
        self.last_gps_time = 0.0
        self.last_gps_lat = 0.0
        self.last_gps_lon = 0.0
        self.last_gps_time_valid = False
        
        self.current_yaw = 0.0
        self.filtered_yaw = 0.0
        
        # GPS COG 계산용
        self.gps_cog = 0.0
        self.gps_speed = 0.0
        self.gps_cog_valid = False
        
        # IMU 데이터
        self.imu_yaw = 0.0
        self.imu_data_received = False
        
        # 퓨전 상태
        self.fusion_initialized = False
        
        # 파라미터 선언
        self.declare_parameter('fusion_method', 'complementary')  # 'complementary' or 'kalman'
        self.declare_parameter('alpha', 0.98)  # Complementary Filter 가중치
        self.declare_parameter('min_gps_speed', 1.0)  # GPS COG 계산 최소 속도 (m/s)
        self.declare_parameter('gps_timeout', 1.0)  # GPS 타임아웃 (초)
        self.declare_parameter('adaptive_alpha', True)  # 적응적 Alpha 사용
        self.declare_parameter('drift_correction', True)  # 드리프트 보정 사용
        self.declare_parameter('drift_based_alpha', True)  # 드리프트 기반 Alpha 조정
        self.declare_parameter('drift_sensitivity', 1.0)  # 드리프트 감도 (0.5~2.0)
        
        # 파라미터 로드
        self.fusion_method = self.get_parameter('fusion_method').value
        self.alpha = self.get_parameter('alpha').value
        self.min_gps_speed = self.get_parameter('min_gps_speed').value
        self.gps_timeout = self.get_parameter('gps_timeout').value
        self.adaptive_alpha = self.get_parameter('adaptive_alpha').value
        self.drift_correction = self.get_parameter('drift_correction').value
        self.drift_based_alpha = self.get_parameter('drift_based_alpha').value
        self.drift_sensitivity = self.get_parameter('drift_sensitivity').value
        
        # 퍼블리셔
        self.filtered_yaw_pub = self.create_publisher(Float64, '/filtered_yaw', 10)
        self.debug_pub = self.create_publisher(Twist, '/yaw_fusion_debug', 10)
        
        # 구독자
        self.imu_sub = self.create_subscription(
            Imu, '/imu/data', self.imu_callback, 10
        )
        self.gps_sub = self.create_subscription(
            NavSatFix, '/ublox_gps_node/fix', self.gps_callback, 10
        )
        
        # 타이머 (퓨전 실행)
        self.timer = self.create_timer(0.01, self.fusion_timer_callback)  # 100Hz
        
        self.get_logger().info("🧭 Yaw Fusion 노드가 시작되었습니다!")
        self.get_logger().info(f"   퓨전 방법: {self.fusion_method}")
        self.get_logger().info(f"   Alpha: {self.alpha}")
        self.get_logger().info(f"   최소 GPS 속도: {self.min_gps_speed} m/s")
        self.get_logger().info("   GPS COG + IMU Yaw 센서 퓨전 시작...")
    
    def euler_from_quaternion(self, x, y, z, w):
        """쿼터니언에서 yaw 각도 추출"""
        t3 = +2.0 * (w * z + x * y)
        t4 = +1.0 - 2.0 * (y * y + z * z)
        yaw_z = math.atan2(t3, t4)
        return yaw_z
    
    def calculate_adaptive_alpha(self):
        """시간에 따른 적응적 Alpha 계산"""
        if not self.adaptive_alpha:
            return self.alpha
        
        current_time = time.time()
        elapsed_time = current_time - self.start_time
        
        # 시간에 따른 Alpha 감소 (IMU 신뢰도 감소)
        if elapsed_time < 300:  # 5분 이내
            adaptive_alpha = 0.98  # IMU 신뢰도 높음
        elif elapsed_time < 1800:  # 30분 이내
            # 5분~30분: 선형 감소 (0.98 → 0.85)
            progress = (elapsed_time - 300) / (1800 - 300)
            adaptive_alpha = 0.98 - (0.98 - 0.85) * progress
        else:  # 30분 이상
            # 30분 이후: 더 급격한 감소 (0.85 → 0.70)
            progress = min((elapsed_time - 1800) / 3600, 1.0)  # 1시간 기준
            adaptive_alpha = 0.85 - (0.85 - 0.70) * progress
        
        return max(adaptive_alpha, 0.70)  # 최소 0.70 유지
    
    def detect_imu_drift(self):
        """IMU 드리프트 감지"""
        if not self.drift_correction or not self.gps_cog_valid:
            return False
        
        # GPS COG와 IMU yaw의 차이 계산
        angle_diff = abs(self.gps_cog - self.imu_yaw)
        if angle_diff > math.pi:
            angle_diff = 2 * math.pi - angle_diff
        
        # 드리프트 임계값 (10도)
        drift_threshold = math.radians(10.0)
        
        return angle_diff > drift_threshold
    
    def calculate_drift_based_alpha(self):
        """드리프트 정도에 따른 Alpha 계산"""
        if not self.drift_based_alpha or not self.gps_cog_valid:
            return self.alpha
        
        # 현재 드리프트 계산
        current_drift = abs(self.gps_cog - self.imu_yaw)
        if current_drift > math.pi:
            current_drift = 2 * math.pi - current_drift
        
        # 드리프트 히스토리에 추가
        self.drift_history.append(current_drift)
        if len(self.drift_history) > self.max_drift_samples:
            self.drift_history.pop(0)
        
        # 평균 드리프트 계산 (최근 샘플들)
        if len(self.drift_history) < 10:
            return self.alpha  # 샘플이 부족하면 기본값 사용
        
        recent_samples = self.drift_history[-20:]  # 최근 20개 샘플
        avg_drift = sum(recent_samples) / len(recent_samples)
        max_drift = max(recent_samples)
        
        # 드리프트 정도에 따른 Alpha 조정
        if avg_drift < self.drift_threshold_light:
            # 경미한 드리프트: IMU 신뢰도 높음
            drift_alpha = 0.95
        elif avg_drift < self.drift_threshold_medium:
            # 중간 드리프트: 균형잡힌 설정
            progress = (avg_drift - self.drift_threshold_light) / (self.drift_threshold_medium - self.drift_threshold_light)
            drift_alpha = 0.95 - (0.95 - 0.85) * progress
        elif avg_drift < self.drift_threshold_heavy:
            # 심한 드리프트: GPS 의존도 증가
            progress = (avg_drift - self.drift_threshold_medium) / (self.drift_threshold_heavy - self.drift_threshold_medium)
            drift_alpha = 0.85 - (0.85 - 0.70) * progress
        else:
            # 매우 심한 드리프트: GPS 의존도 최대
            drift_alpha = 0.70
        
        # 드리프트 감도 적용
        sensitivity_factor = self.drift_sensitivity
        if sensitivity_factor > 1.0:
            # 더 민감하게 조정
            drift_alpha = max(drift_alpha - (sensitivity_factor - 1.0) * 0.1, 0.60)
        elif sensitivity_factor < 1.0:
            # 덜 민감하게 조정
            drift_alpha = min(drift_alpha + (1.0 - sensitivity_factor) * 0.1, 0.98)
        
        return max(drift_alpha, 0.60)  # 최소 0.60 유지
    
    def get_drift_statistics(self):
        """드리프트 통계 정보 반환"""
        if len(self.drift_history) < 5:
            return None
        
        recent_samples = self.drift_history[-20:] if len(self.drift_history) >= 20 else self.drift_history
        avg_drift = sum(recent_samples) / len(recent_samples)
        max_drift = max(recent_samples)
        min_drift = min(recent_samples)
        
        return {
            'avg_drift_deg': math.degrees(avg_drift),
            'max_drift_deg': math.degrees(max_drift),
            'min_drift_deg': math.degrees(min_drift),
            'samples': len(recent_samples)
        }
    
    def imu_callback(self, msg):
        """IMU 데이터 처리"""
        # 쿼터니언에서 yaw 각도 추출
        raw_yaw = self.euler_from_quaternion(
            msg.orientation.x,
            msg.orientation.y,
            msg.orientation.z,
            msg.orientation.w
        )
        
        # 각도 정규화 (-π ~ π)
        while raw_yaw > math.pi:
            raw_yaw -= 2 * math.pi
        while raw_yaw < -math.pi:
            raw_yaw += 2 * math.pi
        
        self.imu_yaw = raw_yaw
        self.imu_data_received = True
        
        if not self.fusion_initialized:
            self.fusion_initialized = True
            self.filtered_yaw = self.imu_yaw
            self.get_logger().info(f"🧭 IMU 초기 yaw: {math.degrees(self.imu_yaw):.1f}°")
    
    def gps_callback(self, msg):
        """GPS 데이터 처리 및 COG 계산"""
        if msg.status.status < 0:  # GPS fix 없음
            self.gps_cog_valid = False
            return
        
        current_time = time.time()
        current_lat = msg.latitude
        current_lon = msg.longitude
        
        # 첫 번째 GPS 데이터
        if not self.last_gps_time_valid:
            self.last_gps_time = current_time
            self.last_gps_lat = current_lat
            self.last_gps_lon = current_lon
            self.last_gps_time_valid = True
            return
        
        # 시간 간격 계산
        dt = current_time - self.last_gps_time
        
        # 최소 시간 간격 확인 (0.1초)
        if dt < 0.1:
            return
        
        # UTM 좌표 변환
        try:
            current_easting, current_northing, _, _ = utm.from_latlon(current_lat, current_lon)
            last_easting, last_northing, _, _ = utm.from_latlon(self.last_gps_lat, self.last_gps_lon)
            
            # 거리 계산
            dx = current_easting - last_easting
            dy = current_northing - last_northing
            distance = math.sqrt(dx*dx + dy*dy)
            
            # 속도 계산
            speed = distance / dt if dt > 0 else 0.0
            self.gps_speed = speed
            
            # COG 계산 (속도가 충분할 때만)
            if speed > self.min_gps_speed:
                cog = math.atan2(dy, dx)
                
                # 각도 정규화 (-π ~ π)
                while cog > math.pi:
                    cog -= 2 * math.pi
                while cog < -math.pi:
                    cog += 2 * math.pi
                
                self.gps_cog = cog
                self.gps_cog_valid = True
                
                # 디버깅 로그 (5초마다)
                if hasattr(self, '_last_gps_debug_time'):
                    if current_time - self._last_gps_debug_time > 5.0:
                        self.get_logger().info(f"📍 GPS COG: {math.degrees(cog):.1f}°, 속도: {speed:.2f} m/s")
                        self._last_gps_debug_time = current_time
                else:
                    self._last_gps_debug_time = current_time
            else:
                self.gps_cog_valid = False
                
        except Exception as e:
            self.get_logger().warn(f"GPS COG 계산 오류: {e}")
            self.gps_cog_valid = False
        
        # 이전 GPS 데이터 업데이트
        self.last_gps_time = current_time
        self.last_gps_lat = current_lat
        self.last_gps_lon = current_lon
    
    def complementary_filter(self):
        """Complementary Filter를 사용한 센서 퓨전"""
        if not self.imu_data_received:
            return
        
        # 시간 기반 적응적 Alpha 계산
        time_based_alpha = self.calculate_adaptive_alpha()
        
        # 드리프트 기반 Alpha 계산
        drift_based_alpha = self.calculate_drift_based_alpha()
        
        # 두 방법 중 더 보수적인 Alpha 선택 (더 낮은 값)
        current_alpha = min(time_based_alpha, drift_based_alpha)
        
        # IMU 드리프트 감지
        is_drift_detected = self.detect_imu_drift()
        
        # 드리프트 감지 시 Alpha 추가 감소
        if is_drift_detected:
            current_alpha = max(current_alpha - 0.1, 0.60)  # 추가 0.1 감소, 최소 0.60
        
        # IMU yaw 사용 (기본값)
        self.filtered_yaw = self.imu_yaw
        
        # GPS COG가 유효할 때만 퓨전
        if self.gps_cog_valid:
            # 각도 차이 계산
            angle_diff = self.gps_cog - self.imu_yaw
            
            # 각도 차이 정규화 (-π ~ π)
            while angle_diff > math.pi:
                angle_diff -= 2 * math.pi
            while angle_diff < -math.pi:
                angle_diff += 2 * math.pi
            
            # Complementary Filter 적용 (적응적 Alpha 사용)
            # filtered_yaw = alpha * imu_yaw + (1-alpha) * gps_cog
            self.filtered_yaw = current_alpha * self.imu_yaw + (1 - current_alpha) * self.gps_cog
            
            # 각도 정규화
            while self.filtered_yaw > math.pi:
                self.filtered_yaw -= 2 * math.pi
            while self.filtered_yaw < -math.pi:
                self.filtered_yaw += 2 * math.pi
    
    def kalman_filter(self):
        """간단한 Kalman Filter를 사용한 센서 퓨전"""
        # TODO: 더 정교한 Kalman Filter 구현
        # 현재는 Complementary Filter와 동일하게 구현
        self.complementary_filter()
    
    def fusion_timer_callback(self):
        """센서 퓨전 실행"""
        if not self.imu_data_received:
            return
        
        # 퓨전 방법 선택
        if self.fusion_method == 'complementary':
            self.complementary_filter()
        elif self.fusion_method == 'kalman':
            self.kalman_filter()
        
        # 필터링된 yaw 발행
        msg = Float64()
        msg.data = self.filtered_yaw
        self.filtered_yaw_pub.publish(msg)
        
        # 디버깅 정보 발행
        current_alpha = self.calculate_adaptive_alpha()
        is_drift_detected = self.detect_imu_drift()
        
        debug_msg = Twist()
        debug_msg.linear.x = self.gps_speed  # GPS 속도
        debug_msg.linear.y = 1.0 if self.gps_cog_valid else 0.0  # GPS COG 유효성
        debug_msg.linear.z = math.degrees(self.gps_cog)  # GPS COG (도)
        debug_msg.angular.x = math.degrees(self.imu_yaw)  # IMU yaw (도)
        debug_msg.angular.y = math.degrees(self.filtered_yaw)  # 필터링된 yaw (도)
        debug_msg.angular.z = current_alpha  # 적응적 Alpha 값
        self.debug_pub.publish(debug_msg)
        
        # 로그 출력 (10초마다)
        if hasattr(self, '_last_log_time'):
            if time.time() - self._last_log_time > 10.0:
                elapsed_time = time.time() - self.start_time
                drift_status = "🚨 드리프트 감지" if is_drift_detected else "✅ 정상"
                
                # 드리프트 통계 정보
                drift_stats = self.get_drift_statistics()
                drift_info = ""
                if drift_stats:
                    drift_info = f", 드리프트: 평균{drift_stats['avg_drift_deg']:.1f}°"
                
                self.get_logger().info(f"🧭 퓨전 결과: IMU={math.degrees(self.imu_yaw):.1f}°, "
                                     f"GPS={math.degrees(self.gps_cog):.1f}°, "
                                     f"Filtered={math.degrees(self.filtered_yaw):.1f}°")
                self.get_logger().info(f"   ⏱️ 경과시간: {elapsed_time/60:.1f}분, "
                                     f"Alpha: {current_alpha:.3f}, {drift_status}{drift_info}")
                self._last_log_time = time.time()
        else:
            self._last_log_time = time.time()

def main(args=None):
    rclpy.init(args=args)
    node = YawFusionNode()
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
