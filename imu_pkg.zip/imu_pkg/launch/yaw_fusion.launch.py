#!/usr/bin/env python3
"""
Yaw Fusion 노드 실행을 위한 Launch 파일
"""

from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration

def generate_launch_description():
    return LaunchDescription([
        # Launch arguments
        DeclareLaunchArgument(
            'fusion_method',
            default_value='complementary',
            description='센서 퓨전 방법 (complementary or kalman)'
        ),
        DeclareLaunchArgument(
            'alpha',
            default_value='0.98',
            description='Complementary Filter 가중치 (0.0~1.0)'
        ),
        DeclareLaunchArgument(
            'min_gps_speed',
            default_value='1.0',
            description='GPS COG 계산 최소 속도 (m/s)'
        ),
        DeclareLaunchArgument(
            'gps_timeout',
            default_value='1.0',
            description='GPS 타임아웃 (초)'
        ),
        
        # Yaw Fusion 노드
        Node(
            package='imu_pkg',
            executable='yaw_fusion_node',
            name='yaw_fusion_node',
            output='screen',
            parameters=[{
                'fusion_method': LaunchConfiguration('fusion_method'),
                'alpha': LaunchConfiguration('alpha'),
                'min_gps_speed': LaunchConfiguration('min_gps_speed'),
                'gps_timeout': LaunchConfiguration('gps_timeout'),
            }],
            remappings=[
                ('/imu/data', '/imu/data'),
                ('/ublox_gps_node/fix', '/ublox_gps_node/fix'),
                ('/filtered_yaw', '/filtered_yaw'),
            ]
        ),
    ])
